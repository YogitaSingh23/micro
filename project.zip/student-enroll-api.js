function createGET_BY_KEY_Request(token, dbName, relName, keyName, keyVal) {
    var req = {
        token: token,
        dbName: dbName,
        rel: relName,
        cmd: "GET_BY_KEY",
        key: { [keyName]: keyVal }
    };
    return JSON.stringify(req);
}

function createPUT_Request(token, jsonObj, dbName, relName) {
    var req = {
        token: token,
        dbName: dbName,
        rel: relName,
        cmd: "PUT",
        record: jsonObj
    };
    return JSON.stringify(req);
}

function createUPDATE_Request(token, jsonObj, dbName, relName, recNo) {
    var req = {
        token: token,
        dbName: dbName,
        rel: relName,
        cmd: "UPDATE",
        rec_no: recNo,
        record: jsonObj
    };
    return JSON.stringify(req);
}
