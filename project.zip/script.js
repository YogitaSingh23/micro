function resetForm() {
    document.getElementById("rollNo").value = "";
    document.getElementById("fullName").value = "";
    document.getElementById("className").value = "";
    document.getElementById("birthDate").value = "";
    document.getElementById("address").value = "";
    document.getElementById("enrollDate").value = "";

    document.getElementById("fullName").disabled = true;
    document.getElementById("className").disabled = true;
    document.getElementById("birthDate").disabled = true;
    document.getElementById("address").disabled = true;
    document.getElementById("enrollDate").disabled = true;

    document.getElementById("save").disabled = true;
    document.getElementById("update").disabled = true;
    document.getElementById("reset").disabled = true;

    document.getElementById("rollNo").disabled = false;
    document.getElementById("rollNo").focus();
}

function validateForm() {
    return ["rollNo", "fullName", "className", "birthDate", "address", "enrollDate"]
        .every(id => document.getElementById(id).value.trim() !== "");
}

function getStudent() {
    var roll = document.getElementById("rollNo").value;
    if (!roll) return;

    var getRequest = createGET_BY_KEY_Request(connToken, dbName, relName, "Roll-No", roll);
    var resJson = executeCommandAtGivenBaseUrl(getRequest, jpdbBaseUrl, "/api/irl");
    var data = JSON.parse(resJson.data);

    if (!data.record) {
        enableFieldsForNewEntry();
    } else {
        fillFormWithData(data.record);
        localStorage.setItem("rec_no", data.rec_no);
        enableFieldsForUpdate();
    }
}

function fillFormWithData(data) {
    document.getElementById("fullName").value = data["Full-Name"];
    document.getElementById("className").value = data["Class"];
    document.getElementById("birthDate").value = data["Birth-Date"];
    document.getElementById("address").value = data["Address"];
    document.getElementById("enrollDate").value = data["Enrollment-Date"];
}

function enableFieldsForNewEntry() {
    ["fullName", "className", "birthDate", "address", "enrollDate"].forEach(id => {
        document.getElementById(id).disabled = false;
    });
    document.getElementById("save").disabled = false;
    document.getElementById("reset").disabled = false;
    document.getElementById("fullName").focus();
}

function enableFieldsForUpdate() {
    ["fullName", "className", "birthDate", "address", "enrollDate"].forEach(id => {
        document.getElementById(id).disabled = false;
    });
    document.getElementById("rollNo").disabled = true;
    document.getElementById("update").disabled = false;
    document.getElementById("reset").disabled = false;
    document.getElementById("fullName").focus();
}

function saveStudent() {
    if (!validateForm()) {
        alert("Please fill all fields.");
        return;
    }
    var studentData = {
        "Roll-No": document.getElementById("rollNo").value,
        "Full-Name": document.getElementById("fullName").value,
        "Class": document.getElementById("className").value,
        "Birth-Date": document.getElementById("birthDate").value,
        "Address": document.getElementById("address").value,
        "Enrollment-Date": document.getElementById("enrollDate").value
    };

    var putReq = createPUT_Request(connToken, studentData, dbName, relName);
    executeCommandAtGivenBaseUrl(putReq, jpdbBaseUrl, "/api/iml");
    alert("Record saved successfully.");
    resetForm();
}

function updateStudent() {
    if (!validateForm()) {
        alert("Please fill all fields.");
        return;
    }
    var studentData = {
        "Full-Name": document.getElementById("fullName").value,
        "Class": document.getElementById("className").value,
        "Birth-Date": document.getElementById("birthDate").value,
        "Address": document.getElementById("address").value,
        "Enrollment-Date": document.getElementById("enrollDate").value
    };

    var rec_no = localStorage.getItem("rec_no");
    var updateReq = createUPDATE_Request(connToken, studentData, dbName, relName, rec_no);
    executeCommandAtGivenBaseUrl(updateReq, jpdbBaseUrl, "/api/iml");
    alert("Record updated successfully.");
    resetForm();
}
