var jpdbBaseUrl = "http://api.login2explore.com:5577";
var connToken = "YOUR_CONNECTION_TOKEN_HERE";
var dbName = "SCHOOL-DB";
var relName = "STUDENT-TABLE";
